package  ma.sir.pmp.dao.criteria.history;

import ma.sir.pmp.zynerator.history.HistCriteria;


public class RessourceHistoryCriteria extends HistCriteria {

}
