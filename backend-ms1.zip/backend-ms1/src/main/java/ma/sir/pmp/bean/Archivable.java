package ma.sir.pmp.bean;

import java.util.Date;

public interface Archivable {

public Boolean getArchive() ;

public void setArchive(Boolean archive);

public Date getDateArchivage() ;

public void setDateArchivage(Date dateArchivage) ;

}
