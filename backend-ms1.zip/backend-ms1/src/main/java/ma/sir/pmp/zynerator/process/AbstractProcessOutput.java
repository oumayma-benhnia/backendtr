package ma.sir.pmp.zynerator.process;
import ma.sir.pmp.zynerator.dto.AuditBaseDto;

public class AbstractProcessOutput extends AuditBaseDto {

}
