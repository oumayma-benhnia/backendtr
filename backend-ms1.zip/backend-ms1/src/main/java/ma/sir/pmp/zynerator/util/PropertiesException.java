package ma.sir.pmp.zynerator.util;

public class PropertiesException extends Exception {
    public PropertiesException(String message) {
        super(message);
    }
}
