package ma.sir.pmp.service.facade.admin;

import java.util.List;
import ma.sir.pmp.bean.core.EntiteAdministrative;
import ma.sir.pmp.dao.criteria.core.EntiteAdministrativeCriteria;
import ma.sir.pmp.dao.criteria.history.EntiteAdministrativeHistoryCriteria;
import ma.sir.pmp.zynerator.service.IService;


public interface EntiteAdministrativeAdminService extends  IService<EntiteAdministrative,EntiteAdministrativeCriteria, EntiteAdministrativeHistoryCriteria>  {




}
