package ma.sir.pmp.zynerator.bean;

public interface BaseEnum {
    String getDisplayText();
}