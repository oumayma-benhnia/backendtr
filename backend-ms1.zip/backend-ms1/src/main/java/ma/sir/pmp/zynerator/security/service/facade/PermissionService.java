package ma.sir.pmp.zynerator.security.service.facade;

import ma.sir.pmp.zynerator.security.bean.Permission;


public interface PermissionService {
    public Permission save(Permission permission);
}
