package ma.sir.pmp.service.facade.admin;

import java.util.List;
import ma.sir.pmp.bean.core.TypeProjet;
import ma.sir.pmp.dao.criteria.core.TypeProjetCriteria;
import ma.sir.pmp.dao.criteria.history.TypeProjetHistoryCriteria;
import ma.sir.pmp.zynerator.service.IService;


public interface TypeProjetAdminService extends  IService<TypeProjet,TypeProjetCriteria, TypeProjetHistoryCriteria>  {




}
