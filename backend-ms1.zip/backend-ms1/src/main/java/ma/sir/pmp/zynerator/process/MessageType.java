package ma.sir.pmp.zynerator.process;

public enum MessageType {ERROR, INFO, WARN}
